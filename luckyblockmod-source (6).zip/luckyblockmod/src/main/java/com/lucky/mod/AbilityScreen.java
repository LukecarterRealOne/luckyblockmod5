package com.lucky.mod;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/** Lucky Block ability menu (press G). */
public class AbilityScreen extends Screen {
    private static boolean castNow = false;

    public AbilityScreen() {
        super(Text.literal("Lucky Block Abilities"));
    }

    private static Text modeText() {
        return Text.literal(castNow ? "Click mode: CAST NOW (hold Lucky Block)" : "Click mode: SELECT (then right-click)");
    }

    @Override
    protected void init() {
        int cols = 3;
        int bw = 130;
        int bh = 20;
        int gap = 6;
        int total = Abilities.NAMES.length;
        int rows = (total + cols - 1) / cols;
        int startX = this.width / 2 - (cols * bw + (cols - 1) * gap) / 2;
        int startY = 44;
        for (int i = 0; i < total; i++) {
            final int id = i;
            int x = startX + (i % cols) * (bw + gap);
            int y = startY + (i / cols) * (bh + gap);
            addDrawableChild(ButtonWidget.builder(Text.literal(Abilities.NAMES[i]), b -> choose(id))
                    .dimensions(x, y, bw, bh).build());
        }
        int by = startY + rows * (bh + gap) + 8;
        addDrawableChild(ButtonWidget.builder(Text.literal("Random Roll"), b -> choose(-1))
                .dimensions(startX, by, bw, bh).build());
        addDrawableChild(ButtonWidget.builder(modeText(), b -> {
            castNow = !castNow;
            b.setMessage(modeText());
        }).dimensions(startX + bw + gap, by, bw * 2 + gap, bh).build());
    }

    private void choose(int id) {
        ClientPlayNetworking.send(new SelectPayload(id, castNow ? 1 : 0));
        this.close();
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 14, 0xFFFFFF);
        ctx.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("Pick an ability, then right-click with the Lucky Block (sneak + right-click = Omega Beam)"),
                this.width / 2, 28, 0xFFE066);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}

package com.lucky.mod;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.IronGolemEntity;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.FireballEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Right-click: random ability.  Sneak + right-click: guaranteed YELLOW OMEGA BEAM.
 */
public class LuckyBlockItem extends Item {
    private static final DustParticleEffect YELLOW = new DustParticleEffect(new Vector3f(1.0f, 0.9f, 0.0f), 2.0f);
    private static final DustParticleEffect GOLD = new DustParticleEffect(new Vector3f(1.0f, 0.65f, 0.0f), 1.4f);
    private static final DustParticleEffect WHITE_HOT = new DustParticleEffect(new Vector3f(1.0f, 1.0f, 0.8f), 1.2f);
    private static final DustParticleEffect GREEN = new DustParticleEffect(new Vector3f(0.3f, 1.0f, 0.4f), 1.3f);

    public LuckyBlockItem(Settings settings) {
        super(settings);
    }

    public static final Map<UUID, Integer> SELECTED = new HashMap<>();
    public static final Set<UUID> SHIELDED = new HashSet<>();
    private static final Set<Integer> ENDED = new HashSet<>();
    private static final int[] COOLDOWNS = {160, 40, 40, 40, 40, 40, 80, 100, 200, 600, 600, 160, 100, 120, 80, 80, 40, 800};

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!(world instanceof ServerWorld sw)) {
            return TypedActionResult.success(stack);
        }
        int a = user.isSneaking() ? 0 : SELECTED.getOrDefault(user.getUuid(), -1);
        if (a < 0 || a >= Abilities.COUNT) {
            a = world.random.nextInt(Abilities.COUNT);
        }
        castAbility(sw, user, a);
        user.getItemCooldownManager().set(this, COOLDOWNS[a]);
        return TypedActionResult.success(stack);
    }

    public void castAbility(ServerWorld sw, PlayerEntity user, int a) {
        switch (a) {
            case 0 -> omegaBeam(sw, user);
            case 1 -> lightningStorm(sw, user);
            case 2 -> meteorShower(sw, user);
            case 3 -> healingNova(sw, user);
            case 4 -> skyLaunch(sw, user);
            case 5 -> goldRain(sw, user);
            case 6 -> gravityWarp(sw, user);
            case 7 -> summonAllies(sw, user);
            case 8 -> orbitalStrike(sw, user);
            case 9 -> aegisShield(sw, user);
            case 10 -> guardianLegion(sw, user);
            case 11 -> blackHole(sw, user);
            case 12 -> frostNova(sw, user);
            case 13 -> tornado(sw, user);
            case 14 -> dragonBreath(sw, user);
            case 15 -> arrowStorm(sw, user);
            case 16 -> blinkStrike(sw, user);
            default -> overdrive(sw, user);
        }
    }

    /** Called when the player clicks an ability in the G menu. */
    public static void onSelect(ServerPlayerEntity player, int ability, boolean castNow) {
        if (ability < -1 || ability >= Abilities.COUNT) return;
        if (ability < 0) {
            SELECTED.remove(player.getUuid());
        } else {
            SELECTED.put(player.getUuid(), ability);
        }
        String name = ability < 0 ? "Random Roll" : Abilities.NAMES[ability];
        player.sendMessage(Text.literal("\u00a76Lucky Block ability: \u00a7e\u00a7l" + name), true);
        if (castNow && ability >= 0 && player.getWorld() instanceof ServerWorld sw) {
            ItemStack held = player.getMainHandStack().getItem() instanceof LuckyBlockItem
                    ? player.getMainHandStack() : player.getOffHandStack();
            if (!(held.getItem() instanceof LuckyBlockItem item)) {
                player.sendMessage(Text.literal("\u00a7cHold the Lucky Block to cast from the menu"), true);
                return;
            }
            if (player.getItemCooldownManager().isCoolingDown(item)) {
                player.sendMessage(Text.literal("\u00a7cLucky Block is recharging!"), true);
                return;
            }
            item.castAbility(sw, player, ability);
            player.getItemCooldownManager().set(item, COOLDOWNS[ability]);
        }
    }

    private static boolean friend(Entity e, PlayerEntity user) {
        return e == user || e.getCommandTags().contains("lbm_ally");
    }

    // ---------------- helpers ----------------
    private static void msg(PlayerEntity p, String text) {
        p.sendMessage(Text.literal(text), true);
    }

    private static boolean gone(ServerWorld sw, PlayerEntity user) {
        return !user.isAlive() || user.isRemoved() || user.getWorld() != sw;
    }

    private record Beam(Vec3d eye, Vec3d dir, double len, Vec3d impact) {}

    private static Beam aim(ServerWorld sw, PlayerEntity user) {
        Vec3d eye = user.getEyePos();
        Vec3d dir = user.getRotationVec(1.0f);
        Vec3d end = eye.add(dir.multiply(96));
        var hit = sw.raycast(new RaycastContext(eye, end, RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE, user));
        boolean miss = hit.getType() == HitResult.Type.MISS;
        double len = miss ? 96 : eye.distanceTo(hit.getPos());
        return new Beam(eye, dir, len, miss ? end : hit.getPos());
    }

    private static Vec3d[] basis(Vec3d dir) {
        Vec3d up = Math.abs(dir.y) > 0.95 ? new Vec3d(1, 0, 0) : new Vec3d(0, 1, 0);
        Vec3d right = dir.crossProduct(up).normalize();
        Vec3d realUp = right.crossProduct(dir).normalize();
        return new Vec3d[]{right, realUp};
    }

    // ---------------- 0: YELLOW OMEGA BEAM ----------------
    // 1.5s charge-up -> 1.8s REAL laser (stretched block-display entities, 4 glowing layers) you can sweep -> huge finale
    private static final double MUZZLE = 3.5;
    private static final String[] BEAM_BLOCKS = {
            "minecraft:yellow_stained_glass", "minecraft:yellow_stained_glass",
            "minecraft:yellow_concrete", "minecraft:white_concrete"};
    private static final double[] BEAM_WIDTHS = {6.0, 3.4, 1.7, 0.8};
    private static int beamCounter = 0;

    private void omegaBeam(ServerWorld sw, PlayerEntity user) {
        msg(user, "\u00a7e\u00a7l\u26a1 CHARGING OMEGA BEAM... \u26a1");
        final int charge = 30;
        final int fire = 36;
        final int id = ++beamCounter;
        user.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, charge + 5, 4, false, false));
        Fx.sound(sw, user.getBlockPos(), SoundEvents.BLOCK_BEACON_ACTIVATE, 3f, 0.5f);
        Fx.screen(sw, user.getPos(), 48, 0f, 0.5f, charge, 0xFFF07A);

        for (int t = 0; t < charge; t++) {
            final int tt = t;
            Scheduler.later(t + 1, () -> chargeTick(sw, user, tt, charge));
        }
        Scheduler.later(charge + 1, () -> fireStart(sw, user));
        for (int t = 0; t < fire; t++) {
            final int tt = t;
            Scheduler.later(charge + 1 + t, () -> beamTick(sw, user, tt, fire, id));
        }
        Scheduler.later(charge + fire + 2, () -> finale(sw, user, id));
    }

    private void chargeTick(ServerWorld sw, PlayerEntity user, int t, int total) {
        if (gone(sw, user)) return;
        float p = t / (float) total;
        Vec3d dir = user.getRotationVec(1f);
        Vec3d c = user.getEyePos().add(dir.multiply(MUZZLE)).add(0, -0.3, 0);
        Vec3d[] ax = basis(dir);
        double radius = 6.0 * (1 - p) + 0.4;
        int pts = 20;
        for (int i = 0; i < pts; i++) {
            double a = Math.PI * 2 * i / pts + t * 0.5;
            Vec3d o = ax[0].multiply(Math.cos(a) * radius).add(ax[1].multiply(Math.sin(a) * radius));
            Fx.burst(sw, GOLD, c.x + o.x, c.y + o.y, c.z + o.z, 1, 0, 0, 0, 0);
            if (i % 3 == 0) {
                Fx.burst(sw, ParticleTypes.END_ROD, c.x + o.x, c.y + o.y, c.z + o.z, 1, 0, 0, 0, 0);
            }
        }
        DustParticleEffect orb = new DustParticleEffect(new Vector3f(1f, 0.92f, 0.1f), 1f + 3f * p);
        Fx.burst(sw, orb, c.x, c.y, c.z, 6, 0.4, 0.4, 0.4, 0);
        if (t % 4 == 0) {
            Fx.sound(sw, user.getBlockPos(), SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 1.5f, 0.5f + 1.5f * p);
        }
        if (t == total - 4) {
            Fx.screen(sw, user.getPos(), 48, 0.35f, 1.2f, 6, 0xFFF07A);
        }
    }

    private void fireStart(ServerWorld sw, PlayerEntity user) {
        if (gone(sw, user)) return;
        msg(user, "\u00a7e\u00a7l\u26a1 YELLOW OMEGA BEAM! \u26a1");
        Vec3d m = user.getEyePos().add(user.getRotationVec(1f).multiply(MUZZLE));
        Fx.sound(sw, user.getBlockPos(), SoundEvents.ENTITY_WARDEN_SONIC_BOOM, 4f, 0.7f);
        Fx.sound(sw, user.getBlockPos(), SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, 3f, 1.4f);
        Fx.burst(sw, ParticleTypes.FLASH, m.x, m.y, m.z, 1, 0, 0, 0, 0);
        Fx.burst(sw, ParticleTypes.SONIC_BOOM, m.x, m.y, m.z, 1, 0, 0, 0, 0);
        Fx.screen(sw, user.getPos(), 96, 1.0f, 4.5f, 44, 0xFFF07A);
    }

    /** SNBT transformation that stretches a unit block into a w x w x len box pointing along q's local +Z. */
    private static String transformSnbt(Quaternionf q, double w, double len) {
        Vector3f tr = new Vector3f((float) (-w / 2), (float) (-w / 2), 0f);
        q.transform(tr);
        return String.format(Locale.ROOT,
                "transformation:{left_rotation:[%.5ff,%.5ff,%.5ff,%.5ff],right_rotation:[0f,0f,0f,1f],"
                        + "scale:[%.4ff,%.4ff,%.4ff],translation:[%.4ff,%.4ff,%.4ff]}",
                q.x, q.y, q.z, q.w, w, w, len, tr.x, tr.y, tr.z);
    }

    private void beamTick(ServerWorld sw, PlayerEntity user, int t, int total, int id) {
        if (gone(sw, user)) return;
        Beam b = aim(sw, user);
        Vec3d dir = b.dir();
        Vec3d origin = b.eye().add(dir.multiply(MUZZLE)).add(0, -0.3, 0);
        double len = Math.max(0.5, b.len() - MUZZLE);
        double grow = Math.min(1.0, (t + 1) / 4.0);
        if (t >= total - 4) grow = Math.min(grow, (total - t) / 4.0);
        double pulse = 1.0 + 0.06 * Math.sin(t * 1.7);
        Quaternionf q = new Quaternionf().rotationTo(0f, 0f, 1f, (float) dir.x, (float) dir.y, (float) dir.z);

        // the actual laser: 4 nested glowing block-display boxes
        for (int k = 0; k < BEAM_BLOCKS.length; k++) {
            double w = BEAM_WIDTHS[k] * grow * pulse;
            String tf = transformSnbt(q, w, len);
            if (t == 0) {
                Fx.cmd(sw, String.format(Locale.ROOT,
                        "summon minecraft:block_display %.3f %.3f %.3f {block_state:{Name:\"%s\"},"
                                + "Tags:[\"lbm_beam\",\"lbm%d\",\"lbm%d_%d\"],view_range:4f,teleport_duration:1,"
                                + "brightness:{sky:15,block:15},%s}",
                        origin.x, origin.y, origin.z, BEAM_BLOCKS[k], id, id, k, tf));
            } else {
                Fx.cmd(sw, String.format(Locale.ROOT,
                        "data merge entity @e[tag=lbm%d_%d,limit=1] {%s,start_interpolation:0,interpolation_duration:1}",
                        id, k, tf));
            }
        }
        if (t > 0) {
            Fx.cmd(sw, String.format(Locale.ROOT, "tp @e[tag=lbm%d] %.3f %.3f %.3f", id, origin.x, origin.y, origin.z));
        }

        // extra energy: crackling sparks + a wide rotating double spiral around the laser
        Vec3d[] ax = basis(dir);
        for (double d = MUZZLE; d <= b.len(); d += 1.2) {
            Vec3d p = b.eye().add(dir.multiply(d)).add(0, -0.3, 0);
            int idx = (int) (d / 1.2);
            if (idx % 2 == 0) {
                Fx.burst(sw, ParticleTypes.ELECTRIC_SPARK, p.x, p.y, p.z, 3, 2.5, 2.5, 2.5, 0.4);
            }
            if (idx % 3 == 0) {
                Fx.burst(sw, ParticleTypes.END_ROD, p.x, p.y, p.z, 2, 1.5, 1.5, 1.5, 0.05);
            }
            double ang = d * 0.9 + t * 0.9;
            for (int s = 0; s < 2; s++) {
                double a = ang + s * Math.PI;
                double r = 3.6 * grow;
                Vec3d o = ax[0].multiply(Math.cos(a) * r).add(ax[1].multiply(Math.sin(a) * r));
                Fx.burst(sw, GOLD, p.x + o.x, p.y + o.y, p.z + o.z, 1, 0, 0, 0, 0);
            }
        }

        if (t % 4 == 0) {
            damageAlong(sw, user, b, 70f, 4.5);
        }

        // impact: bigger fire, lava, smoke, shockwave rings, pillar of light
        Vec3d im = b.impact();
        Fx.burst(sw, ParticleTypes.FLAME, im.x, im.y + 0.3, im.z, 25, 2.5, 0.8, 2.5, 0.1);
        Fx.burst(sw, ParticleTypes.LAVA, im.x, im.y + 0.3, im.z, 6, 2.5, 0.4, 2.5, 0);
        Fx.burst(sw, ParticleTypes.LARGE_SMOKE, im.x, im.y + 0.3, im.z, 12, 2.5, 1.0, 2.5, 0.06);
        Fx.burst(sw, YELLOW, im.x, im.y + 0.5, im.z, 25, 3.0, 1.0, 3.0, 0);
        Fx.ring(sw, YELLOW, im.x, im.y + 0.2, im.z, 2 + (t % 10) * 1.0, 40);
        for (double y = 0; y <= 60; y += 2) {
            Fx.burst(sw, YELLOW, im.x, im.y + y, im.z, 4, 0.9, 0.1, 0.9, 0);
        }
        if (t % 6 == 0) {
            Fx.sound(sw, user.getBlockPos(), SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 2f, 0.5f);
        }
    }

    private void damageAlong(ServerWorld sw, PlayerEntity user, Beam b, float dmg, double radius) {
        Vec3d end = b.eye().add(b.dir().multiply(b.len()));
        List<LivingEntity> targets = sw.getEntitiesByClass(LivingEntity.class,
                new Box(b.eye(), end).expand(radius + 0.5), e -> e != user);
        for (LivingEntity e : targets) {
            Vec3d center = e.getPos().add(0, e.getHeight() / 2, 0);
            double t = MathHelper.clamp(center.subtract(b.eye()).dotProduct(b.dir()), 0, b.len());
            Vec3d closest = b.eye().add(b.dir().multiply(t));
            if (closest.distanceTo(center) <= radius) {
                e.damage(sw.getDamageSources().indirectMagic(user, user), dmg);
                e.setOnFireFor(10);
                e.addVelocity(b.dir().x * 0.8, 0.3, b.dir().z * 0.8);
                e.velocityModified = true;
                Fx.burst(sw, ParticleTypes.EXPLOSION, e.getX(), e.getBodyY(0.5), e.getZ(), 1, 0, 0, 0, 0);
            }
        }
    }

    private void finale(ServerWorld sw, PlayerEntity user, int id) {
        Fx.cmd(sw, "kill @e[tag=lbm" + id + "]");   // always remove the laser entities
        if (gone(sw, user)) return;
        Beam b = aim(sw, user);
        Vec3d im = b.impact();
        sw.createExplosion(user, im.x, im.y, im.z, 8f, World.ExplosionSourceType.NONE);
        Fx.burst(sw, ParticleTypes.EXPLOSION_EMITTER, im.x, im.y, im.z, 1, 0, 0, 0, 0);
        Fx.burst(sw, ParticleTypes.FLASH, im.x, im.y + 1, im.z, 1, 0, 0, 0, 0);
        Fx.sound(sw, user.getBlockPos(), SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, 4f, 0.6f);
        Fx.screen(sw, im, 96, 1.0f, 6.0f, 30, 0xFFF07A);
        damageAlong(sw, user, b, 100f, 6.0);
        for (int k = 0; k < 6; k++) {
            final double r = 2 + k * 4;
            Scheduler.later(k * 2 + 1, () -> {
                Fx.ring(sw, YELLOW, im.x, im.y + 0.3, im.z, r, 64);
                Fx.ring(sw, ParticleTypes.END_ROD, im.x, im.y + 0.6, im.z, r, 32);
            });
        }
    }

    // ---------------- 1: LIGHTNING STORM ----------------
    private void lightningStorm(ServerWorld sw, PlayerEntity user) {
        msg(user, "\u00a7b\u00a7lLightning Storm!");
        for (int i = 0; i < 10; i++) {
            double a = sw.random.nextDouble() * Math.PI * 2;
            double r = 4 + sw.random.nextDouble() * 7;
            final Vec3d pos = user.getPos().add(Math.cos(a) * r, 0, Math.sin(a) * r);
            Scheduler.later(i * 3 + 1, () -> {
                if (gone(sw, user)) return;
                Fx.ring(sw, ParticleTypes.ELECTRIC_SPARK, pos.x, pos.y + 0.1, pos.z, 2.0, 24);
                Fx.sound(sw, user.getBlockPos(), SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, 1.5f, 1.8f);
            });
            Scheduler.later(i * 3 + 13, () -> {
                if (gone(sw, user)) return;
                LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(sw);
                if (bolt != null) {
                    bolt.refreshPositionAfterTeleport(pos);
                    sw.spawnEntity(bolt);
                }
                Fx.burst(sw, ParticleTypes.ELECTRIC_SPARK, pos.x, pos.y + 1, pos.z, 40, 0.6, 1.2, 0.6, 0.4);
                Fx.screen(sw, pos, 64, 0.4f, 1.5f, 8, 0xBFE9FF);
            });
        }
    }

    // ---------------- 2: METEOR SHOWER ----------------
    private void meteorShower(ServerWorld sw, PlayerEntity user) {
        msg(user, "\u00a7c\u00a7lMeteor Shower!");
        Vec3d target = user.getEyePos().add(user.getRotationVec(1f).multiply(18));
        List<FireballEntity> fireballs = new ArrayList<>();
        Fx.screen(sw, user.getPos(), 64, 0.3f, 0.8f, 20, 0xFF7A1A);
        for (int i = 0; i < 8; i++) {
            final Vec3d start = target.add((sw.random.nextDouble() - 0.5) * 12, 25 + sw.random.nextDouble() * 8,
                    (sw.random.nextDouble() - 0.5) * 12);
            Scheduler.later(i * 4 + 1, () -> {
                FireballEntity fb = new FireballEntity(sw, user, new Vec3d(0, -1.2, 0), 2);
                fb.setPosition(start);
                sw.spawnEntity(fb);
                fireballs.add(fb);
                Fx.burst(sw, ParticleTypes.FLAME, start.x, start.y, start.z, 25, 0.6, 0.6, 0.6, 0.1);
                Fx.sound(sw, user.getBlockPos(), SoundEvents.ENTITY_BLAZE_SHOOT, 2f, 0.6f);
            });
        }
        trail(sw, fireballs, 100);
    }

    private void trail(ServerWorld sw, List<FireballEntity> fireballs, int remaining) {
        for (FireballEntity fb : new ArrayList<>(fireballs)) {
            if (!fb.isRemoved()) {
                Fx.burst(sw, ParticleTypes.FLAME, fb.getX(), fb.getY(), fb.getZ(), 5, 0.3, 0.3, 0.3, 0.02);
                Fx.burst(sw, ParticleTypes.LARGE_SMOKE, fb.getX(), fb.getY(), fb.getZ(), 3, 0.3, 0.3, 0.3, 0.02);
                Fx.burst(sw, ParticleTypes.LAVA, fb.getX(), fb.getY(), fb.getZ(), 1, 0.2, 0.2, 0.2, 0);
            }
        }
        if (remaining > 0) {
            Scheduler.later(1, () -> trail(sw, fireballs, remaining - 1));
        }
    }

    // ---------------- 3: HEALING NOVA ----------------
    private void healingNova(ServerWorld sw, PlayerEntity user) {
        msg(user, "\u00a7a\u00a7lHealing Nova!");
        user.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 200, 2));
        user.addStatusEffect(new StatusEffectInstance(StatusEffects.ABSORPTION, 600, 3));
        user.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 200, 1));
        user.setHealth(user.getMaxHealth());
        Fx.sound(sw, user.getBlockPos(), SoundEvents.BLOCK_BEACON_POWER_SELECT, 2f, 1.2f);
        Fx.screen(sw, user.getPos(), 32, 0.3f, 0f, 1, 0x66FF99);
        for (int t = 0; t < 20; t++) {
            final int tt = t;
            Scheduler.later(t + 1, () -> {
                if (gone(sw, user)) return;
                double x = user.getX(), y = user.getY(), z = user.getZ();
                Fx.ring(sw, ParticleTypes.HAPPY_VILLAGER, x, y + 0.1, z, 0.5 + tt * 0.4, 36);
                Fx.ring(sw, GREEN, x, y + 0.2, z, 0.5 + tt * 0.4, 24);
                for (int s = 0; s < 2; s++) {
                    double a = tt * 0.7 + s * Math.PI;
                    Fx.burst(sw, GOLD, x + Math.cos(a), y + tt * 0.12, z + Math.sin(a), 2, 0.05, 0.05, 0.05, 0);
                }
                if (tt == 19) {
                    Fx.burst(sw, ParticleTypes.HEART, x, y + 1.5, z, 20, 0.6, 0.6, 0.6, 0.1);
                }
            });
        }
    }

    // ---------------- 4: SKY LAUNCH ----------------
    private void skyLaunch(ServerWorld sw, PlayerEntity user) {
        msg(user, "\u00a7d\u00a7lSky Launch!");
        user.addVelocity(0, 2.2, 0);
        user.velocityModified = true;
        user.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOW_FALLING, 300, 0));
        Fx.sound(sw, user.getBlockPos(), SoundEvents.ENTITY_FIREWORK_ROCKET_LAUNCH, 2f, 1f);
        Fx.screen(sw, user.getPos(), 48, 0.5f, 2.0f, 8, 0xFFFFFF);
        for (int k = 1; k <= 4; k++) {
            Fx.ring(sw, ParticleTypes.CLOUD, user.getX(), user.getY() + 0.1, user.getZ(), k, 32);
        }
        for (int t = 0; t < 25; t++) {
            final int tt = t;
            Scheduler.later(t + 1, () -> {
                if (gone(sw, user)) return;
                double x = user.getX(), y = user.getY(), z = user.getZ();
                Fx.burst(sw, ParticleTypes.FIREWORK, x, y, z, 6, 0.2, 0.1, 0.2, 0.05);
                Fx.burst(sw, ParticleTypes.CLOUD, x, y, z, 4, 0.3, 0.1, 0.3, 0.02);
                Fx.burst(sw, ParticleTypes.FLAME, x, y, z, 3, 0.15, 0.05, 0.15, 0.02);
                if (tt % 5 == 0) {
                    Fx.ring(sw, ParticleTypes.END_ROD, x, y, z, 1 + tt * 0.1, 20);
                }
            });
        }
    }

    // ---------------- 5: ITEM RAIN ----------------
    // Rains RANDOM items from the whole item registry: vanilla AND every installed mod.
    private void goldRain(ServerWorld sw, PlayerEntity user) {
        List<Item> all = new ArrayList<>();
        for (Item item : Registries.ITEM) {
            if (item != Items.AIR) all.add(item);
        }
        msg(user, "\u00a76\u00a7lITEM RAIN! (" + all.size() + " possible items)");
        final Vec3d base = user.getPos();
        Fx.sound(sw, user.getBlockPos(), SoundEvents.ENTITY_PLAYER_LEVELUP, 2f, 1f);
        Fx.screen(sw, base, 32, 0.35f, 0.6f, 10, 0xFFD84A);
        for (int t = 0; t < 30; t++) {
            Scheduler.later(t + 1, () -> {
                for (double y = 0; y <= 14; y += 1) {
                    Fx.burst(sw, GOLD, base.x, base.y + y, base.z, 2, 0.5, 0, 0.5, 0);
                }
            });
        }
        for (int i = 0; i < 30; i++) {
            Item item = all.get(sw.random.nextInt(all.size()));
            int count = 1 + sw.random.nextInt(Math.max(1, Math.min(item.getMaxCount(), 16)));
            ItemStack loot = new ItemStack(item, count);
            final double x = base.x + (sw.random.nextDouble() - 0.5) * 6;
            final double z = base.z + (sw.random.nextDouble() - 0.5) * 6;
            final double y = base.y + 5 + sw.random.nextDouble() * 3;
            Scheduler.later(i * 2 + 2, () -> {
                sw.spawnEntity(new ItemEntity(sw, x, y, z, loot));
                Fx.burst(sw, ParticleTypes.TOTEM_OF_UNDYING, x, y, z, 10, 0.2, 0.2, 0.2, 0.3);
            });
        }
    }

    // ---------------- targeting helper ----------------
    private record Target(Vec3d pos, LivingEntity entity) {}

    /** What the player is looking at: the nearest living entity on the ray, else the block hit (or far point). */
    private static Target pickTarget(ServerWorld sw, PlayerEntity user, double range) {
        Vec3d eye = user.getEyePos();
        Vec3d dir = user.getRotationVec(1.0f);
        Vec3d end = eye.add(dir.multiply(range));
        var hit = sw.raycast(new RaycastContext(eye, end, RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE, user));
        boolean miss = hit.getType() == HitResult.Type.MISS;
        double bestT = miss ? range : eye.distanceTo(hit.getPos());
        LivingEntity best = null;
        for (LivingEntity e : sw.getEntitiesByClass(LivingEntity.class, new Box(eye, end).expand(2), x -> x != user)) {
            Vec3d c = e.getPos().add(0, e.getHeight() / 2, 0);
            double t = c.subtract(eye).dotProduct(dir);
            if (t < 0 || t > bestT) continue;
            if (eye.add(dir.multiply(t)).distanceTo(c) <= 1.5 + e.getWidth() / 2) {
                best = e;
                bestT = t;
            }
        }
        if (best != null) {
            return new Target(best.getPos().add(0, best.getHeight() / 2, 0), best);
        }
        return new Target(miss ? end : hit.getPos(), null);
    }

    // ---------------- 6: GRAVITY WARP ----------------
    // Look at something: everything in a 7-block bubble loses gravity and floats up, then gets SLAMMED down.
    private void gravityWarp(ServerWorld sw, PlayerEntity user) {
        msg(user, "\u00a75\u00a7lGRAVITY WARP!");
        Target tg = pickTarget(sw, user, 48);
        final Vec3d c = tg.pos();
        final double r = 7;
        final List<LivingEntity> victims = sw.getEntitiesByClass(LivingEntity.class, new Box(c, c).expand(r),
                e -> e != user && e.squaredDistanceTo(c) <= r * r);
        final DustParticleEffect purple = new DustParticleEffect(new Vector3f(0.6f, 0.2f, 1.0f), 1.6f);

        Fx.sound(sw, BlockPos.ofFloored(c), SoundEvents.BLOCK_BEACON_ACTIVATE, 3f, 0.6f);
        Fx.screen(sw, c, 64, 0.3f, 1.0f, 10, 0xAA66FF);
        for (LivingEntity e : victims) {
            e.addStatusEffect(new StatusEffectInstance(StatusEffects.LEVITATION, 60, 3, false, true));
            e.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, 80, 0, false, false));
        }
        for (int t = 0; t < 60; t++) {
            final int tt = t;
            Scheduler.later(t + 1, () -> {
                double rise = (tt % 30) * 0.5;
                Fx.ring(sw, purple, c.x, c.y + rise, c.z, r, 40);
                Fx.ring(sw, ParticleTypes.REVERSE_PORTAL, c.x, c.y + rise, c.z, r * 0.6, 20);
                for (LivingEntity e : victims) {
                    if (e.isAlive()) {
                        Fx.burst(sw, ParticleTypes.PORTAL, e.getX(), e.getY() + e.getHeight() / 2, e.getZ(),
                                6, 0.4, 0.6, 0.4, 0.3);
                    }
                }
                if (tt % 10 == 0) {
                    Fx.sound(sw, BlockPos.ofFloored(c), SoundEvents.BLOCK_BEACON_AMBIENT, 2f, 0.5f);
                }
            });
        }
        Scheduler.later(62, () -> {
            for (LivingEntity e : victims) {
                if (!e.isAlive()) continue;
                e.removeStatusEffect(StatusEffects.LEVITATION);
                e.setVelocity(0, -3.5, 0);
                e.velocityModified = true;
                e.damage(sw.getDamageSources().magic(), 12f);
            }
            Fx.sound(sw, BlockPos.ofFloored(c), SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 3f, 0.7f);
            Fx.screen(sw, c, 64, 0.4f, 2.5f, 12, 0xAA66FF);
            for (int k = 0; k < 6; k++) {
                final double rr = 2 + k * 2.5;
                Scheduler.later(k + 1, () -> Fx.ring(sw, purple, c.x, c.y, c.z, rr, 48));
            }
        });
    }

    // ---------------- 7: ALLY SUMMON (instant, works with modded mobs) ----------------
    private MobEntity spawnAlly(ServerWorld sw, PlayerEntity user, EntityType<?> type, Vec3d pos, boolean guardian) {
        Entity e = null;
        try {
            e = type.create(sw);
        } catch (Exception ignored) {
        }
        if (!(e instanceof MobEntity mob)) return null;
        mob.refreshPositionAndAngles(pos.x, pos.y, pos.z, user.getYaw(), 0f);
        try {
            mob.initialize(sw, sw.getLocalDifficulty(mob.getBlockPos()), SpawnReason.MOB_SUMMONED, null);
        } catch (Exception ignored) {
        }
        if (mob instanceof IronGolemEntity golem) golem.setPlayerCreated(true);
        mob.setPersistent();
        mob.addCommandTag("lbm_ally");
        int dur = guardian ? 2500 : 1300;
        int amp = guardian ? 2 : 1;
        mob.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, dur, amp));
        mob.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, dur, amp));
        mob.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, dur, 1));
        mob.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, dur, 0, false, false));
        if (guardian) {
            mob.addStatusEffect(new StatusEffectInstance(StatusEffects.ABSORPTION, dur, 4));
            mob.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, dur, 0));
            mob.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, dur, 1));
            mob.setCustomName(Text.literal("\u00a7b\u00a7lGuardian"));
            mob.setCustomNameVisible(true);
        }
        mob.setTarget(null);
        sw.spawnEntity(mob);

        LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(sw);
        if (bolt != null) {
            bolt.refreshPositionAfterTeleport(pos);
            bolt.setCosmetic(true);
            sw.spawnEntity(bolt);
        }
        Fx.ring(sw, ParticleTypes.SOUL_FIRE_FLAME, pos.x, pos.y + 0.1, pos.z, 2.0, 24);
        Fx.burst(sw, ParticleTypes.END_ROD, pos.x, pos.y + 1, pos.z, 30, 0.3, 1.2, 0.3, 0.1);
        Fx.burst(sw, ParticleTypes.PORTAL, pos.x, pos.y + 1, pos.z, 40, 0.6, 1.0, 0.6, 0.5);
        return mob;
    }

    private void summonAllies(ServerWorld sw, PlayerEntity user) {
        List<EntityType<?>> modded = new ArrayList<>();
        for (Identifier id : Registries.ENTITY_TYPE.getIds()) {
            String ns = id.getNamespace();
            if (ns.equals("minecraft") || ns.equals(LuckyBlockMod.MOD_ID)) continue;
            EntityType<?> type = Registries.ENTITY_TYPE.get(id);
            if (type.getSpawnGroup() == SpawnGroup.MISC || !type.isSummonable()) continue;
            modded.add(type);
        }
        List<EntityType<?>> fallback = List.<EntityType<?>>of(EntityType.IRON_GOLEM, EntityType.WOLF,
                EntityType.WOLF, EntityType.VINDICATOR, EntityType.IRON_GOLEM);

        msg(user, modded.isEmpty()
                ? "\u00a7b\u00a7lAllies Summoned!"
                : "\u00a7b\u00a7lModded Allies Summoned! (" + modded.size() + " mob types found)");

        final int total = 5;
        final List<MobEntity> allies = new ArrayList<>();
        final Set<UUID> ids = new HashSet<>();
        StringBuilder names = new StringBuilder();
        // everything spawns in the SAME tick
        for (int i = 0; i < total; i++) {
            double a = Math.PI * 2 * i / total;
            Vec3d pos = user.getPos().add(Math.cos(a) * 3.5, 0, Math.sin(a) * 3.5);
            MobEntity mob = null;
            for (int attempt = 0; attempt < 6 && mob == null; attempt++) {
                EntityType<?> type = (!modded.isEmpty() && i < 4 && attempt < 5)
                        ? modded.get(sw.random.nextInt(modded.size()))
                        : fallback.get(i % fallback.size());
                mob = spawnAlly(sw, user, type, pos, false);
            }
            if (mob != null) {
                allies.add(mob);
                ids.add(mob.getUuid());
                if (names.length() > 0) names.append(", ");
                names.append(mob.getType().getName().getString());
            }
        }
        user.sendMessage(Text.literal("\u00a7bSummoned: " + names), false);
        Fx.sound(sw, user.getBlockPos(), SoundEvents.ENTITY_EVOKER_PREPARE_SUMMON, 3f, 1f);
        allyTick(sw, user, allies, ids, 1200, 100.0);
    }

    // ---------------- 10: GUARDIAN LEGION ----------------
    // 6 heavily buffed iron-golem bodyguards that stay close and hit anything that attacks you. Instant.
    private void guardianLegion(ServerWorld sw, PlayerEntity user) {
        msg(user, "\u00a7b\u00a7lGUARDIAN LEGION!");
        final List<MobEntity> allies = new ArrayList<>();
        final Set<UUID> ids = new HashSet<>();
        int total = 6;
        for (int i = 0; i < total; i++) {
            double a = Math.PI * 2 * i / total;
            Vec3d pos = user.getPos().add(Math.cos(a) * 4.5, 0, Math.sin(a) * 4.5);
            MobEntity mob = spawnAlly(sw, user, EntityType.IRON_GOLEM, pos, true);
            if (mob != null) {
                allies.add(mob);
                ids.add(mob.getUuid());
            }
        }
        Fx.sound(sw, user.getBlockPos(), SoundEvents.ENTITY_EVOKER_PREPARE_SUMMON, 3f, 0.7f);
        Fx.screen(sw, user.getPos(), 48, 0.4f, 2.0f, 12, 0x88DDFF);
        for (int k = 0; k < 5; k++) {
            final double r = 2 + k * 2.5;
            Scheduler.later(k + 1, () -> Fx.ring(sw, ParticleTypes.END_ROD, user.getX(), user.getY() + 0.2, user.getZ(), r, 40));
        }
        allyTick(sw, user, allies, ids, 2400, 36.0);
    }

    private void allyTick(ServerWorld sw, PlayerEntity user, List<MobEntity> allies, Set<UUID> ids,
                          int remaining, double followSq) {
        boolean any = false;
        LivingEntity attacker = user.getAttacker();
        for (MobEntity a : allies) {
            if (a.isRemoved() || !a.isAlive()) continue;
            any = true;
            if (remaining <= 0) {
                Fx.burst(sw, ParticleTypes.POOF, a.getX(), a.getY() + 1, a.getZ(), 30, 0.5, 0.8, 0.5, 0.05);
                a.discard();
                continue;
            }
            LivingEntity tgt = a.getTarget();
            if (tgt instanceof PlayerEntity || (tgt != null && ids.contains(tgt.getUuid()))) {
                a.setTarget(null);
            }
            // protect the owner: go after whatever hurt them
            if (attacker != null && attacker.isAlive() && !(attacker instanceof PlayerEntity)
                    && !ids.contains(attacker.getUuid())) {
                a.setTarget(attacker);
            }
            LivingEntity cur = a.getTarget();
            if ((cur == null || !cur.isAlive()) && remaining % 5 == 0) {
                MobEntity best = null;
                double bd = Double.MAX_VALUE;
                for (MobEntity f : sw.getEntitiesByClass(MobEntity.class, a.getBoundingBox().expand(20),
                        m -> m instanceof Monster && m.isAlive() && !ids.contains(m.getUuid()))) {
                    double d = a.squaredDistanceTo(f);
                    if (d < bd) {
                        bd = d;
                        best = f;
                    }
                }
                if (best != null) {
                    a.setTarget(best);
                } else if (a.squaredDistanceTo(user) > followSq) {
                    a.getNavigation().startMovingTo(user, 1.3);
                }
            }
        }
        if (any && remaining > 0) {
            Scheduler.later(1, () -> allyTick(sw, user, allies, ids, remaining - 1, followSq));
        }
    }

    // ---------------- 8: ORBITAL STRIKE ----------------
    // Look anywhere (up to 128 blocks): a targeting reticle locks on, then a giant laser fires down from space.
    private static final String[] ORB_BLOCKS = {
            "minecraft:cyan_stained_glass", "minecraft:light_blue_stained_glass", "minecraft:white_concrete"};
    private static final double[] ORB_WIDTHS = {11.0, 6.5, 3.0};

    private static String verticalBeamSnbt(double w, double h) {
        return String.format(Locale.ROOT,
                "transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],"
                        + "scale:[%.4ff,%.4ff,%.4ff],translation:[%.4ff,0f,%.4ff]}",
                w, h, w, -w / 2, -w / 2);
    }

    private void orbitalStrike(ServerWorld sw, PlayerEntity user) {
        Target tg = pickTarget(sw, user, 128);
        final Vec3d c = tg.pos();
        final int charge = 50;
        final int fire = 50;
        final int id = ++beamCounter;
        final BlockPos bp = BlockPos.ofFloored(c);
        final DustParticleEffect cyan = new DustParticleEffect(new Vector3f(0.3f, 0.9f, 1.0f), 2.0f);

        msg(user, "\u00a7b\u00a7lORBITAL STRIKE LOCKED ON!");
        Fx.sound(sw, bp, SoundEvents.BLOCK_BEACON_ACTIVATE, 4f, 0.5f);

        for (int t = 0; t < charge; t++) {
            final int tt = t;
            Scheduler.later(t + 1, () -> {
                float p = tt / (float) charge;
                double radius = 12 * (1 - p) + 1;
                Fx.ring(sw, cyan, c.x, c.y + 0.2, c.z, radius, 40);
                Fx.ring(sw, cyan, c.x, c.y + 0.2, c.z, 12, 40);
                Fx.ring(sw, ParticleTypes.END_ROD, c.x, c.y + 0.3, c.z, 4, 16);
                for (double y = 0; y <= 80; y += 3) {
                    Fx.burst(sw, ParticleTypes.END_ROD, c.x, c.y + y, c.z, 1, 0.1, 0, 0.1, 0);
                }
                if (tt % 5 == 0) {
                    Fx.sound(sw, bp, SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 3f, 0.5f + 1.5f * p);
                }
                if (tt == charge - 5) {
                    Fx.screen(sw, c, 200, 0.4f, 1.5f, 6, 0xBFEFFF);
                }
            });
        }
        for (int t = 0; t < fire; t++) {
            final int tt = t;
            Scheduler.later(charge + 1 + t, () -> orbitalTick(sw, user, c, cyan, tt, fire, id));
        }
        Scheduler.later(charge + fire + 2, () -> orbitalFinale(sw, user, c, cyan, id));
    }

    private void orbitalTick(ServerWorld sw, PlayerEntity user, Vec3d c, DustParticleEffect cyan,
                             int t, int total, int id) {
        double grow = Math.min(1.0, (t + 1) / 2.0);
        if (t >= total - 6) grow = Math.min(grow, (total - t) / 6.0);
        double pulse = 1.0 + 0.05 * Math.sin(t * 1.9);

        for (int k = 0; k < ORB_BLOCKS.length; k++) {
            double w = ORB_WIDTHS[k] * grow * pulse;
            String tf = verticalBeamSnbt(w, 400);
            if (t == 0) {
                Fx.cmd(sw, String.format(Locale.ROOT,
                        "summon minecraft:block_display %.3f %.3f %.3f {block_state:{Name:\"%s\"},"
                                + "Tags:[\"lbm_beam\",\"lbm%d\",\"lbm%d_%d\"],view_range:8f,"
                                + "brightness:{sky:15,block:15},%s}",
                        c.x, c.y - 2, c.z, ORB_BLOCKS[k], id, id, k, tf));
            } else if (t % 2 == 0) {
                Fx.cmd(sw, String.format(Locale.ROOT,
                        "data merge entity @e[tag=lbm%d_%d,limit=1] {%s,start_interpolation:0,interpolation_duration:2}",
                        id, k, tf));
            }
        }
        if (t == 0) {
            Fx.sound(sw, BlockPos.ofFloored(c), SoundEvents.ENTITY_WARDEN_SONIC_BOOM, 6f, 0.5f);
            Fx.sound(sw, BlockPos.ofFloored(c), SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, 6f, 0.8f);
            Fx.screen(sw, c, 250, 1.0f, 7.0f, 55, 0xBFEFFF);
        }
        if (t % 3 == 0) {
            Box zone = new Box(c.x - 9, c.y - 6, c.z - 9, c.x + 9, c.y + 60, c.z + 9);
            for (LivingEntity e : sw.getEntitiesByClass(LivingEntity.class, zone, e -> e != user)) {
                double dx = e.getX() - c.x;
                double dz = e.getZ() - c.z;
                if (dx * dx + dz * dz <= 81) {
                    e.damage(sw.getDamageSources().indirectMagic(user, user), 60f);
                    e.setOnFireFor(10);
                    e.addVelocity(0, 0.6, 0);
                    e.velocityModified = true;
                }
            }
        }
        Fx.burst(sw, ParticleTypes.FLAME, c.x, c.y + 0.3, c.z, 30, 4.0, 1.0, 4.0, 0.12);
        Fx.burst(sw, ParticleTypes.LAVA, c.x, c.y + 0.3, c.z, 8, 4.0, 0.5, 4.0, 0);
        Fx.burst(sw, ParticleTypes.LARGE_SMOKE, c.x, c.y + 0.3, c.z, 14, 4.0, 1.5, 4.0, 0.06);
        Fx.burst(sw, cyan, c.x, c.y + 0.5, c.z, 30, 4.5, 1.2, 4.5, 0);
        Fx.ring(sw, cyan, c.x, c.y + 0.2, c.z, 3 + (t % 12) * 1.2, 48);
        for (double y = 0; y <= 40; y += 3) {
            Fx.burst(sw, ParticleTypes.ELECTRIC_SPARK, c.x, c.y + y, c.z, 3, 3.5, 1.0, 3.5, 0.4);
        }
        if (t % 6 == 0) {
            Fx.sound(sw, BlockPos.ofFloored(c), SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 4f, 0.5f);
        }
    }

    private void orbitalFinale(ServerWorld sw, PlayerEntity user, Vec3d c, DustParticleEffect cyan, int id) {
        Fx.cmd(sw, "kill @e[tag=lbm" + id + "]");
        sw.createExplosion(user, c.x, c.y, c.z, 10f, World.ExplosionSourceType.NONE);
        Fx.burst(sw, ParticleTypes.EXPLOSION_EMITTER, c.x, c.y, c.z, 1, 0, 0, 0, 0);
        Fx.burst(sw, ParticleTypes.FLASH, c.x, c.y + 1, c.z, 1, 0, 0, 0, 0);
        Fx.sound(sw, BlockPos.ofFloored(c), SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, 6f, 0.5f);
        Fx.screen(sw, c, 250, 1.0f, 8.0f, 35, 0xBFEFFF);
        Box zone = new Box(c.x - 12, c.y - 8, c.z - 12, c.x + 12, c.y + 20, c.z + 12);
        for (LivingEntity e : sw.getEntitiesByClass(LivingEntity.class, zone, e -> e != user)) {
            if (e.squaredDistanceTo(c) <= 144) {
                e.damage(sw.getDamageSources().indirectMagic(user, user), 100f);
                e.setOnFireFor(10);
            }
        }
        for (int k = 0; k < 8; k++) {
            final double r = 3 + k * 4;
            Scheduler.later(k * 2 + 1, () -> {
                Fx.ring(sw, cyan, c.x, c.y + 0.3, c.z, r, 72);
                Fx.ring(sw, ParticleTypes.END_ROD, c.x, c.y + 0.6, c.z, r, 36);
            });
        }
    }

    // ---------------- 9: AEGIS SHIELD ----------------
    // 20s force-field: no damage gets through, projectiles are reflected back, hostile mobs get blasted away.
    private void aegisShield(ServerWorld sw, PlayerEntity user) {
        msg(user, "\u00a7b\u00a7lAEGIS SHIELD ACTIVE!");
        final int id = ++beamCounter;
        final int total = 400;
        SHIELDED.add(user.getUuid());
        Fx.sound(sw, user.getBlockPos(), SoundEvents.BLOCK_BEACON_ACTIVATE, 3f, 1.4f);
        Fx.screen(sw, user.getPos(), 32, 0.4f, 1.0f, 8, 0x88DDFF);
        for (int t = 0; t < total; t++) {
            final int tt = t;
            Scheduler.later(t + 1, () -> shieldTick(sw, user, tt, total, id));
        }
        Scheduler.later(total + 2, () -> shieldEnd(sw, user, id));
    }

    private void shieldTick(ServerWorld sw, PlayerEntity user, int t, int total, int id) {
        if (ENDED.contains(id)) return;
        if (gone(sw, user)) {
            shieldEnd(sw, user, id);
            return;
        }
        final DustParticleEffect blue = new DustParticleEffect(new Vector3f(0.4f, 0.85f, 1.0f), 1.5f);
        Vec3d c = user.getPos().add(0, 1.0, 0);
        if (t == 0) {
            Fx.cmd(sw, String.format(Locale.ROOT,
                    "summon minecraft:block_display %.3f %.3f %.3f {block_state:{Name:\"minecraft:light_blue_stained_glass\"},"
                            + "Tags:[\"lbm_beam\",\"lbm%d\"],view_range:4f,teleport_duration:1,brightness:{sky:15,block:15},"
                            + "transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],"
                            + "scale:[10f,10f,10f],translation:[-5f,-4f,-5f]}}",
                    user.getX(), user.getY(), user.getZ(), id));
        } else {
            Fx.cmd(sw, String.format(Locale.ROOT, "tp @e[tag=lbm%d] %.3f %.3f %.3f", id, user.getX(), user.getY(), user.getZ()));
        }
        // glowing sphere of particles
        for (int i = 0; i < 28; i++) {
            double y = 1 - 2 * (i + 0.5) / 28;
            double rr = Math.sqrt(1 - y * y);
            double a = i * 2.399963 + t * 0.08;
            Fx.burst(sw, blue, c.x + Math.cos(a) * rr * 5.2, c.y + y * 5.2, c.z + Math.sin(a) * rr * 5.2, 1, 0, 0, 0, 0);
            if (i % 4 == 0) {
                Fx.burst(sw, ParticleTypes.END_ROD, c.x + Math.cos(a) * rr * 5.2, c.y + y * 5.2, c.z + Math.sin(a) * rr * 5.2, 1, 0, 0, 0, 0);
            }
        }
        user.extinguish();
        // deflect every projectile that gets close (arrows, fireballs, tridents, mod projectiles...)
        for (ProjectileEntity p : sw.getEntitiesByClass(ProjectileEntity.class, new Box(c, c).expand(7),
                p -> p.getOwner() != user && !p.getCommandTags().contains("lbm_ally"))) {
            if (p.getPos().distanceTo(c) > 6.5) continue;
            Vec3d away = p.getPos().subtract(c);
            if (away.lengthSquared() < 0.01) away = new Vec3d(0, 1, 0);
            away = away.normalize();
            double speed = Math.max(1.5, p.getVelocity().length() * 1.2);
            p.setVelocity(away.x * speed, away.y * speed + 0.05, away.z * speed);
            p.velocityModified = true;
            p.setOwner(user);
            Fx.burst(sw, ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getY(), p.getZ(), 12, 0.2, 0.2, 0.2, 0.3);
            Fx.sound(sw, p.getBlockPos(), SoundEvents.ITEM_SHIELD_BLOCK, 1.5f, 1.2f);
        }
        // blast hostile mobs back
        if (t % 2 == 0) {
            for (MobEntity m : sw.getEntitiesByClass(MobEntity.class, new Box(c, c).expand(6),
                    m -> m instanceof Monster && !m.getCommandTags().contains("lbm_ally"))) {
                Vec3d away = m.getPos().subtract(user.getPos());
                away = new Vec3d(away.x, 0, away.z);
                if (away.lengthSquared() < 0.01) away = new Vec3d(1, 0, 0);
                away = away.normalize().multiply(1.3);
                m.addVelocity(away.x, 0.35, away.z);
                m.velocityModified = true;
                Fx.burst(sw, ParticleTypes.ELECTRIC_SPARK, m.getX(), m.getY() + 1, m.getZ(), 6, 0.3, 0.5, 0.3, 0.2);
            }
        }
        if (t == total - 40) {
            msg(user, "\u00a7c\u00a7lShield ending soon...");
        }
    }

    private void shieldEnd(ServerWorld sw, PlayerEntity user, int id) {
        if (!ENDED.add(id)) return;
        SHIELDED.remove(user.getUuid());
        Fx.cmd(sw, "kill @e[tag=lbm" + id + "]");
        Fx.sound(sw, user.getBlockPos(), SoundEvents.BLOCK_GLASS_BREAK, 3f, 0.8f);
        Fx.burst(sw, ParticleTypes.END_ROD, user.getX(), user.getY() + 1, user.getZ(), 80, 3, 2, 3, 0.2);
    }

    // ---------------- 11: BLACK HOLE ----------------
    private void blackHole(ServerWorld sw, PlayerEntity user) {
        msg(user, "\u00a78\u00a7lBLACK HOLE!");
        Target tg = pickTarget(sw, user, 60);
        final Vec3d c = tg.pos().add(0, 1.5, 0);
        final int id = ++beamCounter;
        final int total = 120;
        Fx.sound(sw, BlockPos.ofFloored(c), SoundEvents.BLOCK_BEACON_ACTIVATE, 4f, 0.5f);
        Fx.cmd(sw, String.format(Locale.ROOT,
                "summon minecraft:block_display %.3f %.3f %.3f {block_state:{Name:\"minecraft:black_concrete\"},"
                        + "Tags:[\"lbm_beam\",\"lbm%d\"],view_range:4f,"
                        + "transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],"
                        + "scale:[3f,3f,3f],translation:[-1.5f,-1.5f,-1.5f]}}",
                c.x, c.y, c.z, id));
        for (int t = 0; t < total; t++) {
            final int tt = t;
            Scheduler.later(t + 1, () -> holeTick(sw, user, c, tt, id));
        }
        Scheduler.later(total + 1, () -> holeEnd(sw, user, c, id));
    }

    private void holeTick(ServerWorld sw, PlayerEntity user, Vec3d c, int t, int id) {
        final DustParticleEffect violet = new DustParticleEffect(new Vector3f(0.5f, 0.1f, 0.9f), 1.8f);
        for (int ring = 0; ring < 4; ring++) {
            double r = 3 + ring * 2.2;
            for (int i = 0; i < 14; i++) {
                double a = Math.PI * 2 * i / 14 + t * (0.45 - ring * 0.07);
                Fx.burst(sw, violet, c.x + Math.cos(a) * r, c.y + Math.sin(a * 2 + t * 0.1) * 0.3, c.z + Math.sin(a) * r, 1, 0, 0, 0, 0);
            }
        }
        Fx.burst(sw, ParticleTypes.PORTAL, c.x, c.y, c.z, 20, 4, 4, 4, 0.8);
        Fx.burst(sw, ParticleTypes.SQUID_INK, c.x, c.y, c.z, 6, 1.5, 1.5, 1.5, 0.05);
        for (LivingEntity e : sw.getEntitiesByClass(LivingEntity.class, new Box(c, c).expand(16), e -> !friend(e, user))) {
            Vec3d mid = e.getPos().add(0, e.getHeight() / 2, 0);
            Vec3d to = c.subtract(mid);
            double d = to.length();
            if (d < 0.5) continue;
            Vec3d pull = to.normalize().multiply(Math.min(0.9, 6.0 / (d + 2)));
            e.setVelocity(e.getVelocity().multiply(0.5).add(pull));
            e.velocityModified = true;
            e.fallDistance = 0;
            if (d < 3 && t % 10 == 0) {
                e.damage(sw.getDamageSources().magic(), 8f);
            }
        }
        if (t % 10 == 0) {
            Fx.sound(sw, BlockPos.ofFloored(c), SoundEvents.BLOCK_BEACON_AMBIENT, 3f, 0.5f);
            Fx.screen(sw, c, 40, 0f, 0.8f, 10, 0x7733CC);
        }
    }

    private void holeEnd(ServerWorld sw, PlayerEntity user, Vec3d c, int id) {
        Fx.cmd(sw, "kill @e[tag=lbm" + id + "]");
        sw.createExplosion(user, c.x, c.y, c.z, 6f, World.ExplosionSourceType.NONE);
        Fx.burst(sw, ParticleTypes.EXPLOSION_EMITTER, c.x, c.y, c.z, 1, 0, 0, 0, 0);
        Fx.burst(sw, ParticleTypes.FLASH, c.x, c.y, c.z, 1, 0, 0, 0, 0);
        Fx.sound(sw, BlockPos.ofFloored(c), SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 4f, 0.5f);
        Fx.screen(sw, c, 80, 1.0f, 6.0f, 25, 0xAA66FF);
        for (LivingEntity e : sw.getEntitiesByClass(LivingEntity.class, new Box(c, c).expand(16), e -> !friend(e, user))) {
            Vec3d away = e.getPos().subtract(c);
            away = away.lengthSquared() < 0.01 ? new Vec3d(1, 0, 0) : away.normalize();
            e.setVelocity(away.x * 2.5, 0.8, away.z * 2.5);
            e.velocityModified = true;
            e.damage(sw.getDamageSources().magic(), 40f);
        }
        final DustParticleEffect violet = new DustParticleEffect(new Vector3f(0.5f, 0.1f, 0.9f), 2.0f);
        for (int k = 0; k < 6; k++) {
            final double r = 2 + k * 3;
            Scheduler.later(k + 1, () -> Fx.ring(sw, violet, c.x, c.y, c.z, r, 56));
        }
    }

    // ---------------- 12: FROST NOVA ----------------
    private void frostNova(ServerWorld sw, PlayerEntity user) {
        msg(user, "\u00a7b\u00a7lFROST NOVA!");
        final Vec3d c = user.getPos();
        final double radius = 14;
        final List<LivingEntity> victims = sw.getEntitiesByClass(LivingEntity.class, new Box(c, c).expand(radius),
                e -> !friend(e, user) && e.squaredDistanceTo(c) <= radius * radius);
        final DustParticleEffect ice = new DustParticleEffect(new Vector3f(0.6f, 0.9f, 1.0f), 1.8f);
        Fx.sound(sw, user.getBlockPos(), SoundEvents.BLOCK_GLASS_BREAK, 3f, 0.6f);
        Fx.screen(sw, c, 48, 0.5f, 1.5f, 10, 0xBFEFFF);
        for (LivingEntity e : victims) {
            e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 100, 6));
            e.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, 100, 0, false, false));
            e.setFrozenTicks(300);
        }
        for (int t = 0; t < 14; t++) {
            final double r = (t + 1) * 1.0;
            Scheduler.later(t + 1, () -> {
                Fx.ring(sw, ice, c.x, c.y + 0.3, c.z, r, 56);
                Fx.ring(sw, ParticleTypes.SNOWFLAKE, c.x, c.y + 0.6, c.z, r, 40);
            });
        }
        for (int t = 0; t < 45; t++) {
            Scheduler.later(t * 2 + 2, () -> {
                for (LivingEntity e : victims) {
                    if (e.isAlive()) {
                        Fx.burst(sw, ParticleTypes.SNOWFLAKE, e.getX(), e.getY() + e.getHeight() / 2, e.getZ(), 8, 0.5, 0.7, 0.5, 0.02);
                    }
                }
            });
        }
        Scheduler.later(92, () -> {
            for (LivingEntity e : victims) {
                if (!e.isAlive()) continue;
                e.damage(sw.getDamageSources().magic(), 30f);
                Fx.burst(sw, ParticleTypes.SNOWFLAKE, e.getX(), e.getY() + e.getHeight() / 2, e.getZ(), 60, 0.6, 0.8, 0.6, 0.3);
                Fx.burst(sw, ice, e.getX(), e.getY() + e.getHeight() / 2, e.getZ(), 20, 0.6, 0.8, 0.6, 0);
            }
            Fx.sound(sw, user.getBlockPos(), SoundEvents.BLOCK_GLASS_BREAK, 4f, 1.2f);
        });
    }

    // ---------------- 13: TORNADO ----------------
    private void tornado(ServerWorld sw, PlayerEntity user) {
        msg(user, "\u00a77\u00a7lTORNADO!");
        Target tg = pickTarget(sw, user, 50);
        final Vec3d c = tg.pos();
        final int total = 140;
        Fx.sound(sw, BlockPos.ofFloored(c), SoundEvents.ENTITY_PHANTOM_FLAP, 4f, 0.5f);
        final DustParticleEffect gray = new DustParticleEffect(new Vector3f(0.8f, 0.8f, 0.85f), 1.8f);
        for (int t = 0; t < total; t++) {
            final int tt = t;
            Scheduler.later(t + 1, () -> {
                for (int h = 0; h <= 16; h++) {
                    double r = 1 + h * 0.35;
                    for (int s = 0; s < 3; s++) {
                        double a = tt * 0.5 + h * 0.6 + s * (Math.PI * 2 / 3);
                        Fx.burst(sw, tt % 2 == 0 ? ParticleTypes.CLOUD : gray,
                                c.x + Math.cos(a) * r, c.y + h * 0.9, c.z + Math.sin(a) * r, 1, 0.05, 0.05, 0.05, 0.01);
                    }
                }
                for (LivingEntity e : sw.getEntitiesByClass(LivingEntity.class, new Box(c, c).expand(7, 18, 7),
                        e -> !friend(e, user))) {
                    double dx = e.getX() - c.x;
                    double dz = e.getZ() - c.z;
                    double d = Math.sqrt(dx * dx + dz * dz);
                    if (d > 7) continue;
                    double len = Math.max(0.5, d);
                    double tx = -dz / len * 0.55;
                    double tz = dx / len * 0.55;
                    e.setVelocity(tx - dx / len * 0.1, 0.2, tz - dz / len * 0.1);
                    e.velocityModified = true;
                    e.fallDistance = 0;
                    if (tt % 10 == 0) {
                        e.damage(sw.getDamageSources().magic(), 4f);
                    }
                }
                if (tt % 20 == 0) {
                    Fx.sound(sw, BlockPos.ofFloored(c), SoundEvents.ENTITY_PHANTOM_FLAP, 3f, 0.6f);
                    Fx.screen(sw, c, 40, 0f, 0.7f, 20, 0xDDDDDD);
                }
            });
        }
    }

    // ---------------- 14: DRAGON BREATH ----------------
    private void dragonBreath(ServerWorld sw, PlayerEntity user) {
        msg(user, "\u00a76\u00a7lDRAGON BREATH!");
        Fx.sound(sw, user.getBlockPos(), SoundEvents.ENTITY_ENDER_DRAGON_GROWL, 3f, 0.8f);
        Fx.screen(sw, user.getPos(), 48, 0.2f, 1.2f, 40, 0xFF7A1A);
        for (int t = 0; t < 40; t++) {
            final int tt = t;
            Scheduler.later(t + 1, () -> breathTick(sw, user, tt));
        }
    }

    private void breathTick(ServerWorld sw, PlayerEntity user, int t) {
        if (gone(sw, user)) return;
        Vec3d eye = user.getEyePos();
        Vec3d dir = user.getRotationVec(1f);
        for (double d = 1.5; d <= 22; d += 1.0) {
            Vec3d p = eye.add(dir.multiply(d)).add(0, -0.3, 0);
            double spread = 0.3 + d * 0.28;
            Fx.burst(sw, ParticleTypes.FLAME, p.x, p.y, p.z, 5, spread * 0.6, spread * 0.6, spread * 0.6, 0.02);
            Fx.burst(sw, ParticleTypes.SOUL_FIRE_FLAME, p.x, p.y, p.z, 2, spread * 0.5, spread * 0.5, spread * 0.5, 0.02);
            if (((int) d) % 3 == 0) {
                Fx.burst(sw, ParticleTypes.LARGE_SMOKE, p.x, p.y, p.z, 1, spread * 0.5, spread * 0.5, spread * 0.5, 0.02);
            }
        }
        if (t % 4 == 0) {
            Vec3d end = eye.add(dir.multiply(22));
            for (LivingEntity e : sw.getEntitiesByClass(LivingEntity.class, new Box(eye, end).expand(6), e -> !friend(e, user))) {
                Vec3d to = e.getPos().add(0, e.getHeight() / 2, 0).subtract(eye);
                double dist = to.length();
                if (dist > 22 || dist < 0.1) continue;
                if (to.normalize().dotProduct(dir) < 0.88) continue;
                e.damage(sw.getDamageSources().magic(), 14f);
                e.setOnFireFor(8);
            }
            Fx.sound(sw, user.getBlockPos(), SoundEvents.ENTITY_BLAZE_SHOOT, 2f, 0.5f);
        }
    }

    // ---------------- 15: ARROW STORM ----------------
    private void arrowStorm(ServerWorld sw, PlayerEntity user) {
        msg(user, "\u00a7e\u00a7lARROW STORM!");
        Target tg = pickTarget(sw, user, 80);
        final Vec3d c = tg.pos();
        final DustParticleEffect red = new DustParticleEffect(new Vector3f(1.0f, 0.2f, 0.2f), 1.6f);
        Fx.sound(sw, BlockPos.ofFloored(c), SoundEvents.ENTITY_ARROW_SHOOT, 3f, 0.6f);
        for (int t = 0; t < 45; t++) {
            final int tt = t;
            Scheduler.later(t + 1, () -> {
                if (tt % 3 == 0) {
                    Fx.ring(sw, red, c.x, c.y + 0.3, c.z, 9, 40);
                }
                for (int k = 0; k < 3; k++) {
                    var arrow = EntityType.ARROW.create(sw);
                    if (arrow == null) continue;
                    double ox = (sw.random.nextDouble() - 0.5) * 18;
                    double oz = (sw.random.nextDouble() - 0.5) * 18;
                    arrow.setPosition(c.x + ox, c.y + 30 + sw.random.nextDouble() * 10, c.z + oz);
                    arrow.setVelocity((sw.random.nextDouble() - 0.5) * 0.2, -3.0, (sw.random.nextDouble() - 0.5) * 0.2);
                    arrow.setOwner(user);
                    arrow.setCritical(true);
                    arrow.setDamage(4.0);
                    arrow.pickupType = PersistentProjectileEntity.PickupPermission.DISALLOWED;
                    sw.spawnEntity(arrow);
                }
            });
        }
    }

    // ---------------- 16: BLINK STRIKE ----------------
    private void blinkStrike(ServerWorld sw, PlayerEntity user) {
        msg(user, "\u00a7e\u00a7lBLINK STRIKE!");
        Vec3d eye = user.getEyePos();
        Vec3d dir = user.getRotationVec(1f);
        Target tg = pickTarget(sw, user, 80);
        double dist = eye.distanceTo(tg.pos());
        Vec3d p = eye.add(dir.multiply(Math.max(1.0, dist - 2.0)));
        Vec3d from = user.getPos();
        final DustParticleEffect trail = new DustParticleEffect(new Vector3f(1.0f, 0.9f, 0.0f), 1.8f);
        for (double d = 0; d <= dist; d += 1.0) {
            Vec3d q = eye.add(dir.multiply(d));
            Fx.burst(sw, trail, q.x, q.y - 0.5, q.z, 3, 0.2, 0.2, 0.2, 0);
            Fx.burst(sw, ParticleTypes.END_ROD, q.x, q.y - 0.5, q.z, 1, 0.1, 0.1, 0.1, 0.02);
        }
        Fx.sound(sw, user.getBlockPos(), SoundEvents.ENTITY_ENDERMAN_TELEPORT, 2f, 1f);
        user.requestTeleport(p.x, p.y - 1.0, p.z);
        final Vec3d to = new Vec3d(p.x, p.y - 1.0, p.z);

        for (Vec3d pos : new Vec3d[]{from, to}) {
            LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(sw);
            if (bolt != null) {
                bolt.refreshPositionAfterTeleport(pos);
                bolt.setCosmetic(true);
                sw.spawnEntity(bolt);
            }
        }
        Fx.sound(sw, BlockPos.ofFloored(to), SoundEvents.ENTITY_ENDERMAN_TELEPORT, 2f, 0.7f);
        Fx.screen(sw, to, 48, 0.8f, 3.0f, 12, 0xFFF07A);
        for (LivingEntity e : sw.getEntitiesByClass(LivingEntity.class, new Box(to, to).expand(6), e -> !friend(e, user))) {
            if (e.squaredDistanceTo(to) > 36) continue;
            e.damage(sw.getDamageSources().indirectMagic(user, user), 30f);
            Vec3d away = e.getPos().subtract(to);
            away = away.lengthSquared() < 0.01 ? new Vec3d(1, 0, 0) : away.normalize();
            e.setVelocity(away.x * 1.5, 0.6, away.z * 1.5);
            e.velocityModified = true;
        }
        for (int k = 0; k < 4; k++) {
            final double r = 1.5 + k * 1.5;
            Scheduler.later(k + 1, () -> Fx.ring(sw, trail, to.x, to.y + 0.3, to.z, r, 36));
        }
    }

    // ---------------- 17: OVERDRIVE ----------------
    private void overdrive(ServerWorld sw, PlayerEntity user) {
        msg(user, "\u00a7c\u00a7lOVERDRIVE!");
        int dur = 600;
        user.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, dur, 2));
        user.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, dur, 2));
        user.addStatusEffect(new StatusEffectInstance(StatusEffects.HASTE, dur, 2));
        user.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, dur, 2));
        user.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, dur, 1));
        user.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, dur, 1));
        user.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, dur, 0));
        Fx.sound(sw, user.getBlockPos(), SoundEvents.ENTITY_ENDER_DRAGON_GROWL, 2f, 1.3f);
        Fx.screen(sw, user.getPos(), 32, 0.6f, 2.5f, 12, 0xFF5522);
        for (int k = 0; k < 5; k++) {
            final double r = 1 + k * 1.5;
            Scheduler.later(k + 1, () -> {
                Fx.ring(sw, ParticleTypes.FLAME, user.getX(), user.getY() + 0.2, user.getZ(), r, 36);
                Fx.ring(sw, GOLD, user.getX(), user.getY() + 0.4, user.getZ(), r, 36);
            });
        }
        for (int t = 0; t < 300; t++) {
            final int tt = t;
            Scheduler.later(t * 2 + 1, () -> {
                if (gone(sw, user)) return;
                double a = tt * 0.6;
                double x = user.getX();
                double y = user.getY() + 0.1 + (tt % 10) * 0.2;
                double z = user.getZ();
                Fx.burst(sw, ParticleTypes.FLAME, x + Math.cos(a) * 0.9, y, z + Math.sin(a) * 0.9, 2, 0.05, 0.05, 0.05, 0.02);
                Fx.burst(sw, GOLD, x + Math.cos(a + Math.PI) * 0.9, y, z + Math.sin(a + Math.PI) * 0.9, 1, 0, 0, 0, 0);
            });
        }
    }
}

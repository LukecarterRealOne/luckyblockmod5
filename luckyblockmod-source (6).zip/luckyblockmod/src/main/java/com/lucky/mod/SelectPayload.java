package com.lucky.mod;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Client -> server: which ability the menu picked (-1 = random) and whether to cast right now (1) or just select (0). */
public record SelectPayload(int ability, int castNow) implements CustomPayload {
    public static final CustomPayload.Id<SelectPayload> ID =
            new CustomPayload.Id<>(Identifier.of(LuckyBlockMod.MOD_ID, "select"));

    public static final PacketCodec<RegistryByteBuf, SelectPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.INTEGER, SelectPayload::ability,
            PacketCodecs.INTEGER, SelectPayload::castNow,
            SelectPayload::new);

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() {
        return ID;
    }
}

package com.lucky.mod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class LuckyBlockMod implements ModInitializer {
    public static final String MOD_ID = "luckyblockmod";

    public static final Item LUCKY_BLOCK = Registry.register(
            Registries.ITEM,
            Identifier.of(MOD_ID, "lucky_block"),
            new LuckyBlockItem(new Item.Settings().maxCount(1)));

    public static final ItemGroup LUCKY_TAB = Registry.register(
            Registries.ITEM_GROUP,
            Identifier.of(MOD_ID, "main"),
            FabricItemGroup.builder()
                    .icon(() -> new ItemStack(LUCKY_BLOCK))
                    .displayName(Text.literal("Lucky Block"))
                    .entries((context, entries) -> entries.add(LUCKY_BLOCK))
                    .build());

    @Override
    public void onInitialize() {
        PayloadTypeRegistry.playS2C().register(FxPayload.ID, FxPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(SelectPayload.ID, SelectPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(SelectPayload.ID, (payload, context) ->
                context.server().execute(() ->
                        LuckyBlockItem.onSelect(context.player(), payload.ability(), payload.castNow() == 1)));
        Scheduler.init();
        // Summoned allies can never damage any player (covers melee, arrows, and mod attacks)
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (entity instanceof PlayerEntity shielded
                    && LuckyBlockItem.SHIELDED.contains(shielded.getUuid())
                    && !source.isIn(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
                return false; // Aegis Shield: nothing gets through
            }
            if (entity instanceof PlayerEntity) {
                Entity attacker = source.getAttacker();
                Entity direct = source.getSource();
                if ((attacker != null && attacker.getCommandTags().contains("lbm_ally"))
                        || (direct != null && direct.getCommandTags().contains("lbm_ally"))) {
                    return false;
                }
            }
            return true;
        });
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> e.add(LUCKY_BLOCK));
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(e -> e.add(LUCKY_BLOCK));
    }
}

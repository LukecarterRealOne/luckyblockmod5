package com.lucky.mod;

public class Abilities {
    public static final String[] NAMES = {
            "Omega Beam", "Lightning Storm", "Meteor Shower", "Healing Nova", "Sky Launch", "Item Rain",
            "Gravity Warp", "Ally Summon", "Orbital Strike", "Aegis Shield", "Guardian Legion",
            "Black Hole", "Frost Nova", "Tornado", "Dragon Breath", "Arrow Storm", "Blink Strike", "Overdrive"
    };
    public static final int COUNT = NAMES.length;
}
